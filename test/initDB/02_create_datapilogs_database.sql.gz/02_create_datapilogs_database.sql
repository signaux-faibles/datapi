CREATE DATABASE datapilogs_test WITH encoding 'UTF8';
